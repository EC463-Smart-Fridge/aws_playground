import json
import os
import requests

# Access the secrets / api keys stored in github secrets

def findProductUsingUPC(upc, api_key):
    # Define the API endpoint URL
    
    url = f"https://api.nal.usda.gov/fdc/v1/foods/search?api_key={api_key}&query={upc}"

    try:
        # Send an HTTP GET request to the API endpoint
        response = requests.get(url)

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Parse the JSON response
            data = response.json()
            response_data = json.dumps(data, indent=4)
            return response_data

        else:
            print(f"ERROR: {response.status_code}: {response.text}")
            exit(-1)

    except Exception as e:
        print(f"ERROR: Failed to request UPC information: {str(e)}")
        exit(-1)

def getInfoFromJSON(response_json):

    try:
        data = json.loads(response_json)
        name = data["foods"][0]["description"].lstrip().capitalize()
        category = data["foods"][0]["foodCategory"].lstrip().capitalize()
        calories = next((block["value"] for block in data["foods"][0]["foodNutrients"] if block["nutrientId"] == 1008), 0)
        return name, category, calories
    except Exception as e:
        print(f"ERROR: Failed to parse JSON data: {str(e)}")
        exit(-1)
    

def lambda_handler(event, context):
    # Define the url to send the request to
    upc = event['UPC']
    api_key = "DEMO_KEY"
    response_json = findProductUsingUPC(upc, api_key)
    name, category, cal = getInfoFromJSON(response_json)
    response_info = {
        "name" : name,
        "category" : category,
        "calories" : cal
    }

    return {
        'statusCode': 200,
        'body': response_info
    }

print(lambda_handler({"UPC": "878589001707"}, None))